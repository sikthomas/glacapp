package com.veterinary.Account;

import java.util.Date;

/**
 * Created by sikanga on 11/03/2019.
 */

public class IssueList extends postID{
    private String imageUrl,myuser_id,issue;
    private Date timeStamp;

    public IssueList() {
    }

    public IssueList(String imageUrl, String myuser_id, String issue, Date timeStamp) {
        this.imageUrl = imageUrl;
        this.myuser_id = myuser_id;
        this.issue = issue;
        this.timeStamp = timeStamp;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getMyuser_id() {
        return myuser_id;
    }

    public void setMyuser_id(String myuser_id) {
        this.myuser_id = myuser_id;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }
}
